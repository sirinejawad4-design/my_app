import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../../generated/app_colors.dart';
import '../../../../../generated/style_atoms.dart';
import '../../../../core/widgets/custom_button.dart';

class ReviewAppointmentScreen extends StatefulWidget {
  final String doctorId;
  final String doctorName;
  final String specialty;
  final String date;
  final String time;
  final String fee;

  const ReviewAppointmentScreen({
    super.key,
    required this.doctorId,
    required this.doctorName,
    required this.specialty,
    required this.date,
    required this.time,
    required this.fee,
  });

  @override
  State<ReviewAppointmentScreen> createState() =>
      _ReviewAppointmentScreenState();
}

class _ReviewAppointmentScreenState
    extends State<ReviewAppointmentScreen> {
  bool _isSaving = false;

  Future<void> _confirmAppointment() async {
    if (_isSaving) return;

    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Please login before booking an appointment.',
          ),
        ),
      );
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      await FirebaseFirestore.instance
          .collection('appointments')
          .add({
        'userId': user.uid,
        'doctorId': widget.doctorId,
        'doctorName': widget.doctorName,
        'specialty': widget.specialty,
        'date': widget.date,
        'time': widget.time,
        'fee': widget.fee,
        'location': 'Central Clinic',
        'status': 'upcoming',
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;

    context.push('/appointments');
    } catch (e) {
      debugPrint('APPOINTMENT ERROR: $e');

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Error: $e',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isSaving = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,

      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        leading: const BackButton(
          color: AppColors.black,
        ),
        title: Text(
          'Review Appointment',
          style: context.bold16TextMain,
        ),
        centerTitle: true,
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,

          children: [
            Text(
              'Appointment Details',
              style: context.bold16TextMain,
            ),

            const SizedBox(height: 16),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),

              decoration: BoxDecoration(
                color: AppColors.grey100,
                borderRadius: BorderRadius.circular(16),
              ),

              child: Column(
                children: [
                  _InfoRow(
                    title: 'Doctor Name',
                    value: widget.doctorName,
                  ),

                  const Divider(height: 24),

                  _InfoRow(
                    title: 'Specialty',
                    value: widget.specialty,
                  ),

                  const Divider(height: 24),

                  _InfoRow(
                    title: 'Date & Time',
                    value: '${widget.date} • ${widget.time}',
                  ),

                  const Divider(height: 24),

                  _InfoRow(
                    title: 'Fee',
                    value: '\$${widget.fee}',
                  ),

                  const Divider(height: 24),

                  const _InfoRow(
                    title: 'Location',
                    value: 'Central Clinic',
                  ),
                ],
              ),
            ),

            const SizedBox(height: 32),

            CustomButton(
              text: _isSaving
                  ? 'Confirming...'
                  : 'Confirm Appointment',

              onPressed: () {
                if (!_isSaving) {
                  _confirmAppointment();
                }
              },
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String title;
  final String value;

  const _InfoRow({
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,

      children: [
        Expanded(
          child: Text(
            title,
            style: context.regular12TextSub,
          ),
        ),

        const SizedBox(width: 16),

        Expanded(
          flex: 2,
          child: Text(
            value,
            textAlign: TextAlign.right,
            style: context.semiBold14TextMain,
          ),
        ),
      ],
    );
  }
}