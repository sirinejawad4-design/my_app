import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:table_calendar/table_calendar.dart';

import 'package:my_app/apps/features/admin/data/models/doctor.dart';

import '../../../../../generated/app_colors.dart';
import '../../../../../generated/style_atoms.dart';
import '../../../../core/widgets/custom_button.dart';

class SelectTimeScreen extends StatefulWidget {
  final String doctorId;

  const SelectTimeScreen({
    super.key,
    required this.doctorId,
  });

  @override
  State<SelectTimeScreen> createState() =>
      _SelectTimeScreenState();
}

class _SelectTimeScreenState
    extends State<SelectTimeScreen> {
  late Future<Doctor?> _doctorFuture;

  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();

  String? _selectedTime;

  final List<String> _availableTimes = [
    '10:00 AM',
    '11:30 AM',
    '01:00 PM',
    '02:30 PM',
    '04:00 PM',
    '05:30 PM',
  ];

  @override
  void initState() {
    super.initState();
    _doctorFuture = _loadDoctor();
  }

  Future<Doctor?> _loadDoctor() async {
    final doc = await FirebaseFirestore.instance
        .collection('doctors')
        .doc(widget.doctorId)
        .get();

    if (!doc.exists || doc.data() == null) {
      return null;
    }

    return Doctor.fromMap(
      doc.id,
      doc.data()!,
    );
  }

  void _onConfirmPressed(Doctor doctor) {
    if (_selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Please select a time',
            style: context.regular12White,
          ),
          backgroundColor: AppColors.danger,
        ),
      );
      return;
    }

    context.push(
  '/review-appointment'
  '?doctorId=${Uri.encodeComponent(doctor.id)}'
  '&doctorName=${Uri.encodeComponent(doctor.name)}'
  '&specialty=${Uri.encodeComponent(doctor.specialty)}'
  '&date=${Uri.encodeComponent(
    '${_selectedDay.day}/${_selectedDay.month}/${_selectedDay.year}',
  )}'
  '&time=${Uri.encodeComponent(_selectedTime!)}'
  '&fee=${Uri.encodeComponent(
    doctor.fee.toStringAsFixed(0),
  )}',
);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,

      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,

        leading: const BackButton(
          color: AppColors.black,
        ),

        title: Text(
          'Select Time',
          style: context.bold16TextMain,
        ),

        centerTitle: true,
      ),

      body: FutureBuilder<Doctor?>(
        future: _doctorFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState ==
              ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(
                color: AppColors.primary,
              ),
            );
          }

          if (snapshot.hasError) {
            return const Center(
              child: Text(
                'Something went wrong.\nPlease try again.',
                textAlign: TextAlign.center,
              ),
            );
          }

          final doctor = snapshot.data;

          if (doctor == null) {
            return const Center(
              child: Text(
                'Doctor not found.',
                textAlign: TextAlign.center,
              ),
            );
          }

          return _buildContent(
            context,
            doctor,
          );
        },
      ),
    );
  }

  Widget _buildContent(
    BuildContext context,
    Doctor doctor,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(
        horizontal: 20,
      ),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),

          // ============================================================
          // DOCTOR CARD
          // ============================================================

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),

            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: AppColors.grey100,
            ),

            child: Row(
              children: [
                _buildDoctorImage(
                  doctor.imageUrl,
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,

                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              doctor.name,
                              style:
                                  context.semiBold14TextMain,
                              maxLines: 1,
                              overflow:
                                  TextOverflow.ellipsis,
                            ),
                          ),

                          const SizedBox(width: 6),

                          const Icon(
                            Icons.favorite,
                            color: AppColors.danger,
                            size: 16,
                          ),
                        ],
                      ),

                      const SizedBox(height: 3),

                      Text(
                        doctor.specialty,
                        style:
                            context.regular11TextSub,
                      ),

                      const SizedBox(height: 4),

                      Row(
                        children: List.generate(
                          5,
                          (index) => const Icon(
                            Icons.star,
                            size: 12,
                            color: AppColors.warning,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // ============================================================
          // CALENDAR
          // ============================================================

          Text(
            'Select Date',
            style: context.bold16TextMain,
          ),

          const SizedBox(height: 10),

          Container(
            width: double.infinity,

            padding: const EdgeInsets.all(8),

            decoration: BoxDecoration(
              color: AppColors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: AppColors.grey100,
              ),
            ),

            child: TableCalendar(
              firstDay: DateTime.now(),

              lastDay: DateTime.now().add(
                const Duration(days: 90),
              ),

              focusedDay: _focusedDay,

              selectedDayPredicate: (day) {
                return isSameDay(
                  _selectedDay,
                  day,
                );
              },

              onDaySelected: (
                selectedDay,
                focusedDay,
              ) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                  _selectedTime = null;
                });
              },

              calendarFormat:
                  CalendarFormat.month,

              headerStyle: HeaderStyle(
                formatButtonVisible: false,
                titleCentered: true,

                titleTextStyle:
                    context.semiBold14TextMain,
              ),

              calendarStyle: CalendarStyle(
                selectedDecoration:
                    const BoxDecoration(
                  color: AppColors.primary,
                  shape: BoxShape.circle,
                ),

                todayDecoration:
                    BoxDecoration(
                  color: AppColors.primary
                      .withValues(alpha: 0.30),
                  shape: BoxShape.circle,
                ),

                defaultTextStyle:
                    context.regular14TextMain,

                weekendTextStyle:
                    context.regular14TextMain,

                outsideTextStyle:
                    context.regular12TextSub,
              ),
            ),
          ),

          const SizedBox(height: 24),

          // ============================================================
          // AVAILABLE TIME
          // ============================================================

          Text(
            'Available Time',
            style: context.bold16TextMain,
          ),

          const SizedBox(height: 12),

          Wrap(
            spacing: 10,
            runSpacing: 10,

            children: _availableTimes.map(
              (time) {
                final bool isSelected =
                    _selectedTime == time;

                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedTime = time;
                    });
                  },

                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 11,
                    ),

                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.primary
                          : AppColors.grey100,

                      borderRadius:
                          BorderRadius.circular(8),

                      border: Border.all(
                        color: isSelected
                            ? AppColors.primary
                            : AppColors.grey100,
                      ),
                    ),

                    child: Text(
                      time,

                      style: isSelected
                          ? context.semiBold12White
                          : context.regular12TextMain,
                    ),
                  ),
                );
              },
            ).toList(),
          ),

          const SizedBox(height: 32),

          // ============================================================
          // CONFIRM BUTTON
          // ============================================================

          CustomButton(
            text: 'Confirm',
            onPressed: () {
              _onConfirmPressed(doctor);
            },
          ),

          const SizedBox(height: 24),

          // ============================================================
          // SELECTED DATE / TIME SUMMARY
          // ============================================================

          if (_selectedTime != null)
            Center(
              child: Text(
                '${_selectedDay.day}/'
                '${_selectedDay.month}/'
                '${_selectedDay.year}'
                ' • $_selectedTime',

                style: context.regular12TextSub,
              ),
            ),

          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildDoctorImage(String imageUrl) {
    if (imageUrl.isEmpty) {
      return const CircleAvatar(
        radius: 28,
        backgroundColor: AppColors.white,
        child: Icon(
          Icons.person,
          color: AppColors.textSub,
        ),
      );
    }

    return ClipOval(
      child: Image.network(
        imageUrl,
        width: 56,
        height: 56,
        fit: BoxFit.cover,
        errorBuilder: (
          context,
          error,
          stackTrace,
        ) {
          return const CircleAvatar(
            radius: 28,
            backgroundColor: AppColors.white,
            child: Icon(
              Icons.person,
              color: AppColors.textSub,
            ),
          );
        },
      ),
    );
  }
}