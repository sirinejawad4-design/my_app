import '../models/doctor_model.dart';

class DoctorsRepository {
  static const List<DoctorModel> popularDoctors = [
    DoctorModel(
      name: 'Dr. Fillerup Grab',
      specialty: 'Medicine Specialist',
      rating: '4.5',
      reviews: '124',
      fee: r'$50',
    ),
    DoctorModel(
      name: 'Dr. Criss Adam',
      specialty: 'Cardiologist',
      rating: '4.8',
      reviews: '186',
      fee: r'$60',
    ),
    DoctorModel(
      name: 'Dr. John Smith',
      specialty: 'Neurologist',
      rating: '4.7',
      reviews: '142',
      fee: r'$55',
    ),
  ];

  static const List<DoctorModel> topRatedDoctors = [
    DoctorModel(
      name: 'Dr. Sarah Wilson',
      specialty: 'Cardiologist',
      rating: '4.9',
      reviews: '210',
      fee: r'$70',
    ),
    DoctorModel(
      name: 'Dr. Michael Lee',
      specialty: 'Pediatrician',
      rating: '4.9',
      reviews: '198',
      fee: r'$65',
    ),
    DoctorModel(
      name: 'Dr. Emma Brown',
      specialty: 'Neurologist',
      rating: '4.8',
      reviews: '175',
      fee: r'$60',
    ),
  ];
}
