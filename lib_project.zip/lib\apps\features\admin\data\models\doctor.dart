class Doctor {
  final String id;
  final String name;
  final String specialty;
  final String imageUrl;
  final double fee;
  final double rating;
  final int reviewsCount;
  final bool isActive;

  const Doctor({
    required this.id,
    required this.name,
    required this.specialty,
    required this.imageUrl,
    required this.fee,
    required this.rating,
    required this.reviewsCount,
    required this.isActive,
  });

  factory Doctor.fromMap(String id, Map<String, dynamic> data) {
    return Doctor(
      id: id,
      name: data['name'] as String? ?? '',
      specialty: data['specialty'] as String? ?? '',
      imageUrl: data['imageUrl'] as String? ?? '',
      fee: (data['fee'] as num?)?.toDouble() ?? 0.0,
      rating: (data['rating'] as num?)?.toDouble() ?? 0.0,
      reviewsCount: (data['reviewsCount'] as num?)?.toInt() ?? 0,
      isActive: data['isActive'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'specialty': specialty,
      'imageUrl': imageUrl,
      'fee': fee,
      'rating': rating,
      'reviewsCount': reviewsCount,
      'isActive': isActive,
    };
  }
}