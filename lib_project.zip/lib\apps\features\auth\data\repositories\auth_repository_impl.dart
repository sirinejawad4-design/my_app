import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../domain/entities/auth_user.dart';
import '../../domain/repositories/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  final FirebaseAuth _firebaseAuth;
  final GoogleSignIn _googleSignIn;

  AuthRepositoryImpl({
    FirebaseAuth? firebaseAuth,
    GoogleSignIn? googleSignIn,
  })  : _firebaseAuth = firebaseAuth ?? FirebaseAuth.instance,
        _googleSignIn = googleSignIn ?? GoogleSignIn.instance;

  @override
  Future<AuthUser> login({
    required String email,
    required String password,
  }) async {
    final cleanEmail = email.trim();
    final cleanPassword = password.trim();

    if (cleanEmail.isEmpty) {
      throw const AuthRepositoryException(
        'Please enter your email.',
      );
    }

    if (cleanPassword.isEmpty) {
      throw const AuthRepositoryException(
        'Please enter your password.',
      );
    }

    final credential =
        await _firebaseAuth.signInWithEmailAndPassword(
      email: cleanEmail,
      password: cleanPassword,
    );

    return _mapUser(credential.user);
  }

  @override
  Future<AuthUser> signUp({
    required String name,
    required String email,
    required String password,
  }) async {
    final cleanName = name.trim();
    final cleanEmail = email.trim();
    final cleanPassword = password.trim();

    if (cleanName.isEmpty) {
      throw const AuthRepositoryException(
        'Please enter your name.',
      );
    }

    if (cleanEmail.isEmpty) {
      throw const AuthRepositoryException(
        'Please enter your email.',
      );
    }

    if (cleanPassword.isEmpty) {
      throw const AuthRepositoryException(
        'Please enter your password.',
      );
    }

    final credential =
        await _firebaseAuth.createUserWithEmailAndPassword(
      email: cleanEmail,
      password: cleanPassword,
    );

    final user = credential.user;

    if (user == null) {
      throw const AuthRepositoryException(
        'Unable to create user.',
      );
    }

    await user.updateDisplayName(cleanName);
    await user.reload();

    return _mapUser(_firebaseAuth.currentUser);
  }

  @override
  Future<AuthUser> signInWithGoogle() async {
    try {
      final GoogleSignInAccount googleUser =
          await _googleSignIn.authenticate();

      final GoogleSignInAuthentication googleAuth =
          googleUser.authentication;

      final credential = GoogleAuthProvider.credential(
        idToken: googleAuth.idToken,
      );

      final userCredential =
          await _firebaseAuth.signInWithCredential(credential);

      return _mapUser(userCredential.user);
    } catch (e) {
      throw AuthRepositoryException(
        'Google sign in failed: $e',
      );
    }
  }

  AuthUser _mapUser(User? user) {
    if (user == null) {
      throw const AuthRepositoryException(
        'Unable to get user information.',
      );
    }

    return AuthUser(
      id: user.uid,
      email: user.email,
      name: user.displayName,
    );
  }
}

class AuthRepositoryException implements Exception {
  final String message;

  const AuthRepositoryException(this.message);

  @override
  String toString() => message;
}